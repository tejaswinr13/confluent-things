#!/bin/sh

gzcat ./KAFKA_MAIN_data.tar.gz | tar xfv -
