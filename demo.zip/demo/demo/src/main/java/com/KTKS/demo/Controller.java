package com.KTKS.demo;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecordBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.InputStream;

@RestController
public class Controller {
    @Autowired
    KafkaTemplate kafkaTemplate;
    @GetMapping(value = "/start")
    public @ResponseBody
    String getResponse() throws IOException {

        Schema.Parser parser = new Schema.Parser();
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream ispage = classloader.getResourceAsStream("pageview.avsc");
        Schema schemaPage = parser.parse(ispage);
        InputStream isuser = classloader.getResourceAsStream("userprofile.avsc");

        GenericRecordBuilder pageBuilder = new GenericRecordBuilder(schemaPage);
        pageBuilder.set("user", "Teja2");
        pageBuilder.set("page", "Page 2");
        pageBuilder.set("industry", "industry 2");
        pageBuilder.set("flags", "flags 2");
        GenericData.Record myPage = pageBuilder.build();
        Schema schemaUser = parser.parse(isuser);

        GenericRecordBuilder userBuilder = new GenericRecordBuilder(schemaUser);
        userBuilder.set("experience", "experience2");
        userBuilder.set("region", "region2");

        GenericData.Record myUser = userBuilder.build();
        System.out.println("User "+myUser);
        System.out.println("myPage "+myPage);

        kafkaTemplate.send("PageViews","1112",myPage);
        kafkaTemplate.send("UserProfiles","2222",myUser);

        return myPage.toString()+myUser.toString();
    }

}
