//package com.KTKS.demo.config;
//
//
//import com.wba.api.eapirxrcreatepatientaggregator.processor.AvroEntityProcessor;
//import io.confluent.kafka.streams.serdes.avro.GenericAvroSerde;
//import org.apache.avro.generic.GenericRecord;
//import org.apache.kafka.common.serialization.Serde;
//import org.apache.kafka.common.serialization.Serdes;
//import org.apache.kafka.common.serialization.Serdes.StringSerde;
//import org.apache.kafka.streams.KafkaStreams;
//import org.apache.kafka.streams.StreamsConfig;
//import org.apache.kafka.streams.Topology;
//import org.apache.kafka.streams.state.KeyValueStore;
//import org.apache.kafka.streams.state.StoreBuilder;
//import org.apache.kafka.streams.state.Stores;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Properties;
//
//
//@Configuration
//public class StreamConfig {
//
//	@Value("${kafka.inputTopic}")
//	private String inputTopic;
//	@Value("${kafka.outputTopic}")
//	private String outputTopic;
//	@Value("${kafka.bootstrapServers}")
//	private String bootstrapServers;
//	@Value("${kafka.applicationIdConfig}")
//	private String applicationIdConfig;
//	@Value("${kafka.schemaRegistryUrl_key}")
//	private String schemaRegistryUrl_key ;
//	@Value("${kafka.schemaregistryurl_value}")
//	private String schemaregistryurl_value;
//	@Value("${kafka.basicAuth_key}")
//	private String basicAuth_key;
//	@Value("${kafka.basicAuth_value}")
//	private String basicAuth_value;
//	@Value("${kafka.basicAuthCredentials_key}")
//	private String basicAuthCredentials_key;
//	@Value("${kafka.basicAuthCredentials_value}")
//	private String basicAuthCredentials_value;
//	@Value("${kafka.securityProtocol_key}")
//	private String securityProtocol_key;
//	@Value("${kafka.securityProtocol_value}")
//	private String securityProtocol_value;
//	@Value("${kafka.saslMechanism_key}")
//	private String saslMechanism_key;
//	@Value("${kafka.saslMechanism_value}")
//	private String saslMechanism_value;
//	@Value("${kafka.sslAlgorithm_key}")
//	private String sslAlgorithm_key;
//	@Value("${kafka.sslAlgorithm_value}")
//	private String sslAlgorithm_value;
//	@Value("${kafka.saslConfig_key}")
//	private String saslConfig_key;
//	@Value("${kafka.saslConfig_value}")
//	private String saslConfig_value;
//
//	private Class<GenericAvroSerde> serde_key=GenericAvroSerde.class;
//
//
//	 KafkaStreams streams = null;
//    public Properties getConfig (){
//        final Properties props = new Properties();
//        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
//        props.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationIdConfig);
//        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,	serde_key);//"${kafka.serde_key}"
//        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, serde_key);//"${kafka.serde_value}"
//        props.put(schemaRegistryUrl_key,schemaregistryurl_value );
//        props.put(basicAuth_key,basicAuth_value);
//        props.put(basicAuthCredentials_key,basicAuthCredentials_value);
//        props.put(securityProtocol_key,securityProtocol_value);
//        props.put(saslMechanism_key,saslMechanism_value);
//        props.put(sslAlgorithm_key,sslAlgorithm_value);
//        props.put(saslConfig_key,saslConfig_value );
//        return props;
//    }
//
//
//    @Bean
//	public void startKafkaStream() {
//		Topology builder  = new Topology();
//		Serde<GenericRecord> genericAvroSerde = new GenericAvroSerde();
//		boolean isKeySerde = false;
//		Map<String,String> srdeConfigMap = new HashMap<>();
//		srdeConfigMap.put(schemaRegistryUrl_key, schemaregistryurl_value);
//		srdeConfigMap.put(basicAuth_key,basicAuth_value);
//		srdeConfigMap.put(basicAuthCredentials_key,basicAuthCredentials_value);
//		genericAvroSerde.configure(srdeConfigMap,isKeySerde);
//		StoreBuilder<KeyValueStore<String, GenericRecord>> storeBuilder = Stores.keyValueStoreBuilder(Stores.persistentKeyValueStore("patient-store"), Serdes.String(), genericAvroSerde).withLoggingDisabled();
//try{
//	final Map<String, String> serdeConfig = new HashMap();
//	serdeConfig.put(schemaRegistryUrl_key, schemaregistryurl_value);
//	serdeConfig.put(basicAuth_key,basicAuth_value);
//	serdeConfig.put(basicAuthCredentials_key,basicAuthCredentials_value);
//	final Serde<GenericRecord> valueGenericAvroSerde = new GenericAvroSerde();
//	valueGenericAvroSerde.configure(serdeConfig, false);
//	StringSerde ss = new StringSerde();
//	builder.addSource("Source", ss.deserializer(), valueGenericAvroSerde.deserializer(),inputTopic)
//			.addProcessor("Process", () -> {
//				try {
//					return new AvroEntityProcessor("");
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//				return null;
//			}, "Source")
//			.addStateStore(storeBuilder,"Process")
//			.addSink("Sink", outputTopic,ss.serializer(), valueGenericAvroSerde.serializer(), "Process");
//	Properties props = getConfig();
//	streams = new KafkaStreams(builder, props);
//
//	streams.start();
//}catch (Exception e){
//	e.printStackTrace();
//}
//
//	}
//
//}
