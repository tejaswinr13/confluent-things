# springboot-kafka
Spring Boot Kafka Producer and Consumer Example
