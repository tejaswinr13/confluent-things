# Currency Exchange Rates Converter
Given 

| Currencies |Rate|
|------------|-----|
| EUR/USD    | 1.2|
| USD/GBP    | 0.75|
| GBP/AUD    | 1.7|

write a method

`double getRate(String fromCur, String toCur)`

for example 

`double x = getRate("USD", "AUD")`
