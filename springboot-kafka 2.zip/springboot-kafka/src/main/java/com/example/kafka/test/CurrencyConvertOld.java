package com.example.kafka.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CurrencyConvertOld {
    private static final Map<String, Pair<String, Double>> currencyRates = new HashMap<>();
    /*
    given
    EUR/USD 1.2
    USD/GBP 0.75
    GBP/AUD 1.7
    need to find
    USD/AUD ?
    algorithm: find the path to match requested currencies and requested rate by multiplying rates such as:
    USD/AUD = USD/GBP -> GBP/AUD

    (USD/GBP) = 1/(GBP/AUD) -> USD/AUD
    (0.75) = 1/(1.7) -> USD/AUD


    note: it should also work for EUR/AUD
    */
    static {
        currencyRates.put("EUR", new Pair<>("USD", 1.2));
        currencyRates.put("USD", new Pair<>("GBP", 0.75));
        currencyRates.put("GBP", new Pair<>("AUD", 1.7));
    }
//USD AUD
    static double getRate(String fromCur, String toCur) {
       Pair<String,Double> from= currencyRates.get(fromCur);
       Pair<String,Double> to= currencyRates.get(toCur);
       Double amt = 10.0;
        Pair usdTpAud;
        Double usdAud = null;
     if(fromCur.equalsIgnoreCase("USD")){
        usdAud = convert(fromCur,toCur,amt);

     }
        return usdAud;
    }

    static double convert(String cur, String toCur,Double amt){
        Pair usdTogbp =  currencyRates.get("USD");
        Double usdGbp = amt*(Double) usdTogbp.y;
        //convert(usdTogbp.x.toString(),usdGbp);
        return usdGbp;
    }



    public static void main(String[] args) {
        for (String srcCur: currencyRates.keySet()) {
            Pair<String, Double> pair = currencyRates.get(srcCur);
            System.out.println(srcCur + "/" + pair.x + " - " + pair.y);
        }

        try {
            double x = getRate("USD", "AUD");


            if (x != 1.275) {
                System.out.println("Check your logic, expected 1.275 but got " + x);
            }
            else {
                System.out.println("Your logic is correct");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}