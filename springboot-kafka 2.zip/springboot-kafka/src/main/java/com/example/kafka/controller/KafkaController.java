package com.example.kafka.controller;

import com.example.kafka.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/kafka")
public class KafkaController {

    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;

    @GetMapping(value = "/sendp/{message}")
    public String send(@PathVariable String message){
        System.out.printf("11111111111");
//CII-HeartBeat-Partition01-MessageCII
        kafkaTemplate.send("oitospot",1,"CII-HeartBeat","HeartBeat-Message-CII");
//CWI-HeartBeat-Partition02-MessageCWI
        kafkaTemplate.send("oitospot",2,"CWI-HeartBeat","HeartBeat-Message-CWI");

//CRGI-HeartBeat-Partition03-MessageCRGI
        kafkaTemplate.send("oitospot",3,"CRGI-HeartBeat","HeartBeat-Message-CRGI");
//CII-Order-Partition04-MessageCII
        kafkaTemplate.send("oitospot",4,"CII-Order","Order-Message-CII");
//CWI-Order-Partition05-MessageCWI
        kafkaTemplate.send("oitospot",5,"CWI-Order","Order-Message-CWI");
//CRGI-Order-Partition06-MessageOrderCRGI
        kafkaTemplate.send("oitospot",0,"CRGI-Order","Order-Message-CRGI");
        kafkaTemplate.send("oitospot2",0,"CRGI-Order","########## oitospot2 ##########");
        kafkaTemplate.send("oitospot3",0,"CRGI-Order","########## oitospot3 ##########");
        kafkaTemplate.send("oitospot4",0,"CRGI-Order","########## oitospot4 ##########");
        kafkaTemplate.send("oitospot5",0,"CRGI-Order","########## oitospot5 ##########");
        kafkaTemplate.send("oitospot6",0,"CRGI-Order","########## oitospot6 ##########");
        kafkaTemplate.send("oitospot7",0,"CRGI-Order","########## oitospot7 ##########");
        return "ok";
    }
}
