package com.example.kafka.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CurrencyConvert {
    private static final Map<String, Pair<String, Double>> currencyRates = new HashMap<>();
    private static  String frmCur = null;
    private static  String toCur = null;
    private static Double rate = 1.0;
    /*
    given
    EUR/USD 1.2
    USD/GBP 0.75
    GBP/AUD 1.7
    need to find
    USD/AUD ?
    algorithm: find the path to match requested currencies and requested rate by multiplying rates such as:
    USD/AUD = USD/GBP -> GBP/AUD
    1.275 = 0.75 * 1.7


    note: it should also work for EUR/AUD
    EUR/AUD = EUR/USD -> USD/GBP -> GBP/AUD-
    = 1.2 * 0.75 * 1.7
    */
    static {
        currencyRates.put("EUR", new Pair<>("USD", 1.2));
        currencyRates.put("USD", new Pair<>("GBP", 0.75));
        currencyRates.put("GBP", new Pair<>("AUD", 1.7));
    }

    static double getRate(String fromCur) {
        Pair p = currencyRates.get(fromCur);
        rate = rate*(Double)p.y;
        fromCur = p.x.toString();
        while (!toCur.equalsIgnoreCase(fromCur)){
            getRate(fromCur);
        }
        return rate;
    }

    public static void main(String[] args) {
        for (String srcCur: currencyRates.keySet()) {
            Pair<String, Double> pair = currencyRates.get(srcCur);
            System.out.println(srcCur + "/" + pair.x + " - " + pair.y);
        }
        frmCur = "USD";
        toCur = "AUD";


        try {
            double x = getRate(frmCur);
            if (x != 1.275) {
                System.out.println("Check your logic, expected 1.275 but got " + x);
            }
            else {
                System.out.println("Your logic is correct");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}